package com.dh.catalogservice.domain.model;

public record Movie(Long id, String name, String genre, String urlStream) {
}
