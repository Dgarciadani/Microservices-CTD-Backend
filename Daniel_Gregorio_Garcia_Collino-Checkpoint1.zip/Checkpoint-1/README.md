
# Movie-Catalog Microservices




## Running Tests

Para probar la solución cree una serie de test en Postman, dejo el link para que puedan importar la colección:
https://www.getpostman.com/collections/6f4fcc999474219b4b26